-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2018 at 08:07 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodavailability`
--

CREATE TABLE `bloodavailability` (
  `utype` varchar(128) DEFAULT NULL,
  `id` varchar(128) NOT NULL,
  `A_Pos` varchar(128) DEFAULT NULL,
  `A_Neg` varchar(128) DEFAULT NULL,
  `B_Pos` varchar(128) DEFAULT NULL,
  `B_Neg` varchar(128) DEFAULT NULL,
  `AB_Pos` varchar(128) DEFAULT NULL,
  `AB_Neg` varchar(128) DEFAULT NULL,
  `O_Pos` varchar(128) DEFAULT NULL,
  `O_Neg` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bloodavailability`
--

INSERT INTO `bloodavailability` (`utype`, `id`, `A_Pos`, `A_Neg`, `B_Pos`, `B_Neg`, `AB_Pos`, `AB_Neg`, `O_Pos`, `O_Neg`) VALUES
('BloodBank', 'B1', '91', '9', '65', '08', '688', '39', '23', '79'),
('BloodBank', 'B10', '9', '6', '5', '5', '6', '8', '39', '1'),
('BloodBank', 'B11', '4', '4', '4', '55', '6', '5', '5', '2'),
('BloodBank', 'B12', '2', '4', '4', '2', '2', '4', '4', '2'),
('BloodBank', 'B13', '2', '2', '2', '2', '2', '2', '2', '2'),
('BloodBank', 'B14', '23', '31', '24', '24', '42', '13', '13', '13'),
('BloodBank', 'B15', '34', '13', '431', '13', '35', '35', '45', '424'),
('BloodBank', 'B2', '123', '79', '82', '864', '146', '11', '179', '137'),
('BloodBank', 'B3', '145', '146', '149', '148', '176', '164', '1346', '123'),
('BloodBank', 'B4', '84', '75', '65', '00', '9', '09', '70', '82'),
('BloodBank', 'B5', '88', '22', '656', '43', '22', '11', '0', '11'),
('BloodBank', 'B6', '21', '252', '58', '2', '46', '22', '58', '12'),
('BloodBank', 'B7', '9', '5', '6', '8', '2', '8', '9', '7'),
('BloodBank', 'B8', '23', '45', '67', '85', '2', '24', '57', '32'),
('BloodBank', 'B9', '7', '57', '24', '25', '64', '4', '567', '32'),
('Hospital', 'H1', '12', '16', '13', '7', '9', '46', '13', '13'),
('Hospital', 'H10', '146', '165', '132', '149', '123', '114', '146', '123'),
('Hospital', 'H11', '164', '123', '184', '146', '134', '189', '179', '146'),
('Hospital', 'H12', '1123', '112', '1364', '194', '146', '94', '92', '94'),
('Hospital', 'H13', '12', '16', '13', '7', '9', '46', '13', '13'),
('Hospital', 'H14', '50', '13', '19', '22', '23', '24', '25', '26'),
('Hospital', 'H15', '27', '30', '28', '11', '23', '58', '13', '21'),
('Hospital', 'H2', '79', '13', '15', '15', '112', '113', '11', '3'),
('Hospital', 'H3', '0', '12', '14', '13', '12', '122', '56', '13'),
('Hospital', 'H4', '13', '15', '14', '33', '46', '76', '74', '79'),
('Hospital', 'H5', '1123', '112', '1364', '194', '146', '94', '92', '94'),
('Hospital', 'H6', '581', '1321', '70', '65', '84', '80', '14', '7'),
('Hospital', 'H7', '99', '82', '2', '60', '6', '0', '7', '77'),
('Hospital', 'H8', '91', '99', '9', '0', '9', '6', '2', '59'),
('Hospital', 'H9', '91', '1', '1', '6', '81', '34', '65', '13');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank`
--

CREATE TABLE `bloodbank` (
  `Bid` varchar(128) NOT NULL,
  `password` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bloodbank`
--

INSERT INTO `bloodbank` (`Bid`, `password`) VALUES
('B1', 'B1b1'),
('B10', 'B10b10'),
('B11', 'B11b11'),
('B12', 'B12b12'),
('B13', 'B13b13'),
('B14', 'B14b14'),
('B15', 'B15b15'),
('B2', 'B2b2'),
('B3', 'B3b3'),
('B4', 'B4b4'),
('B5', 'B5b5'),
('B6', 'B6b6'),
('B7', 'Bnewbnew'),
('B8', 'B8b8'),
('B9', 'B9b9');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `utype` varchar(128) DEFAULT NULL,
  `id` varchar(128) NOT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `pincode` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`utype`, `id`, `phone`, `pincode`) VALUES
('BloodBank', 'B1', '200001', '1'),
('BloodBank', 'B10', '201010', '3'),
('BloodBank', 'B11', '201011', '4'),
('BloodBank', 'B12', '201100', '4'),
('BloodBank', 'B13', '201101', '3'),
('BloodBank', 'B14', '201110', '2'),
('BloodBank', 'B15', '201111', '1'),
('BloodBank', 'B2', '200010', '3'),
('BloodBank', 'B3', '200011', '4'),
('BloodBank', 'B4', '200100', '4'),
('BloodBank', 'B5', '200101', '3'),
('BloodBank', 'B6', '200110', '2'),
('BloodBank', 'B7', '200111', '1'),
('BloodBank', 'B8', '201000', '1'),
('BloodBank', 'B9', '201001', '2'),
('Hospital', 'H1', '100001', '4'),
('Hospital', 'H10', '101010', '3'),
('Hospital', 'H11', '101011', '2'),
('Hospital', 'H12', '101100', '1'),
('Hospital', 'H13', '101101', '2'),
('Hospital', 'H14', '101110', '4'),
('Hospital', 'H15', '101111', '3'),
('Hospital', 'H2', '100010', '3'),
('Hospital', 'H3', '100011', '2'),
('Hospital', 'H4', '100100', '1'),
('Hospital', 'H5', '100101', '1'),
('Hospital', 'H6', '100110', '2'),
('Hospital', 'H7', '100111', '3'),
('Hospital', 'H8', '101000', '4'),
('Hospital', 'H9', '101001', '4');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `username` varchar(128) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `bloodgroup` varchar(128) DEFAULT NULL,
  `gender` varchar(128) DEFAULT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `pincode` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`username`, `email`, `password`, `bloodgroup`, `gender`, `phone`, `pincode`) VALUES
('D1', 'd1@gmail.com', 'D1d1', 'A+', 'Male', '000001', '1'),
('D10', 'd10@gmail.com', 'D10d10', 'AB+', 'Female', '001010', '2'),
('D11', 'd11@gmail.com', 'D11d11', 'AB-', 'Female', '001011', '3'),
('D12', 'd12@gmail.com', 'D12d12', 'A+', 'Male', '001100', '4'),
('D13', 'd13@gmail.com', 'D13d13', 'A-', 'Female', '001101', '1'),
('D14', 'd14@gmail.com', 'D14d14', 'B+', 'Female', '001110', '2'),
('D15', 'd15@gmail.com', 'D15d15', 'B-', 'Female', '001111', '3'),
('D16', 'd16@gmail.com', 'D16d16', 'O-', 'Female', '010000', '4'),
('D17', 'd17@gmail.com', 'D17d17', 'O+', 'Male', '010001', '1'),
('D18', 'd18@gmail.com', 'D18d18', 'O-', 'Female', '010010', '2'),
('D19', 'd19@gmail.com', 'D19d19', 'B-', 'Female', '010011', '3'),
('D2', 'd2@gmail.com', 'D2d2', 'B+', 'Female', '000010', '2'),
('D20', 'd20@gmail.com', 'D20d20', 'AB+', 'Male', '0100100', '4'),
('D3', 'd3@gmail.com', 'D3d3', 'B-', 'Female', '000011', '3'),
('D4', 'd4@gmail.com', 'D4d4', 'B+', 'Male', '000100', '4'),
('D5', 'd5@gmail.com', 'D5d5', 'O+', 'Female', '000101', '1'),
('D6', 'd6@gmail.com', 'D6d6', 'A-', 'Female', '000110', '2'),
('D7', 'd7@gmail.com', 'D7d7', 'B+', 'Female', '000111', '3'),
('D8', 'd8@gmail.com', 'D8d8', 'B-', 'Male', '001000', '4'),
('D9', 'd9@gmail.com', 'D9d9', 'AB-', 'Female', '001001', '1');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hid` varchar(128) NOT NULL,
  `password` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hid`, `password`) VALUES
('H1', 'H1h1'),
('H10', 'H10h10'),
('H11', 'H11h11'),
('H12', 'H12h12'),
('H13', 'H13h13'),
('H14', 'H14h14'),
('H15', 'H15h15'),
('H2', 'H2h2'),
('H3', 'Hnewhnew'),
('H4', 'H4h4'),
('H5', 'H5h5'),
('H6', 'H6h6'),
('H7', 'H7h7'),
('H8', 'H8h8'),
('H9', 'H9h9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodavailability`
--
ALTER TABLE `bloodavailability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank`
--
ALTER TABLE `bloodbank`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
