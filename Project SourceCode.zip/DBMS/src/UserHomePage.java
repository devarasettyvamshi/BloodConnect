import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;

public class UserHomePage {

	public JFrame frame;
	public JTextField txtVipan;
	public JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserHomePage window = new UserHomePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserHomePage() {
		initialize();
	}
	public UserHomePage(String s,String k) {
		initialize(s,k);
	}
	public void close(JFrame Window){
		Window.setVisible(false);
	}
	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize(String s,String k) {
		frame = new JFrame();
		frame.setBounds(100, 100, 661, 409);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtVipan = new JTextField();
		txtVipan.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtVipan.setBounds(41, 34, 146, 29);
		frame.getContentPane().add(txtVipan);
		txtVipan.setColumns(10);
		txtVipan.setText(s);
		
		JLabel lblNewLabel = new JLabel("Last Donated");
		lblNewLabel.setBounds(41, 113, 86, 29);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 12));
		textField.setColumns(10);
		textField.setBounds(147, 113, 116, 21);
		frame.getContentPane().add(textField);
		textField.setText(k);
		
		
		JButton btnNewButton = new JButton("Update Info");
		btnNewButton.setBounds(38, 227, 109, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.setBounds(204, 227, 139, 23);
		frame.getContentPane().add(btnChangePassword);
		
		JButton btnDeleteAccount = new JButton("Delete Account");
		btnDeleteAccount.setBounds(410, 227, 139, 23);
		frame.getContentPane().add(btnDeleteAccount);
		
		JButton btnSignOut = new JButton("Sign Out");
		btnSignOut.setBounds(222, 306, 109, 23);
		frame.getContentPane().add(btnSignOut);
		
		btnDeleteAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String q = "DELETE FROM donor where username='"+txtVipan.getText()+"'";
				try {
					String url = "jdbc:mysql://localhost:3306/bloodconnect";
				 	String username = "root";
				   String password = "";
				  
				   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
				   Statement st=conn.createStatement();
					int rs=st.executeUpdate(q);
						String s="Account Deleted";
						JOptionPane.showConfirmDialog(null, s);
						EventQueue.invokeLater(new Runnable() {
							public void run() {
								try {
								//	BloodBankHomePage window = new BloodBankHomePage(uname);
								//	window.frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
					
					close(frame);
					
					
					conn.close();
				}catch(Exception w) {
					System.out.println(w);
				}
				
			}
		});
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
								EventQueue.invokeLater(new Runnable() {
									public void run() {
										try {
											UpdateInfo window = new UpdateInfo(s);
											window.frame.setVisible(true);
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
								});
			
			}
		});
		
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close(frame);
				String s="Log Out successfully";
				JOptionPane.showConfirmDialog(null, s);
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							SignupPage window = new SignupPage();
							window.frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdatePassword window = new UpdatePassword(txtVipan.getText(),"Donor");
				window.frame.setVisible(true);
			}
		});
		
		JLabel lblBloodConnect = new JLabel("Blood Connect ++");
		lblBloodConnect.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblBloodConnect.setBounds(340, -17, 277, 120);
		frame.getContentPane().add(lblBloodConnect);
	}
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 661, 409);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtVipan = new JTextField();
		txtVipan.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtVipan.setBounds(41, 34, 146, 29);
		frame.getContentPane().add(txtVipan);
		txtVipan.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Last Donated");
		lblNewLabel.setBounds(41, 113, 86, 29);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 12));
		textField.setColumns(10);
		textField.setBounds(147, 113, 116, 21);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton = new JButton("Update Info");
		btnNewButton.setBounds(38, 227, 109, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.setBounds(204, 227, 139, 23);
		frame.getContentPane().add(btnChangePassword);
		
		JButton btnDeleteAccount = new JButton("Delete Account");
		btnDeleteAccount.setBounds(410, 227, 139, 23);
		frame.getContentPane().add(btnDeleteAccount);
		
		JButton btnSignOut = new JButton("Sign Out");
		btnSignOut.setBounds(222, 306, 109, 23);
		frame.getContentPane().add(btnSignOut);
		
		JLabel lblBloodConnect = new JLabel("Blood Connect ++");
		lblBloodConnect.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblBloodConnect.setBounds(340, -17, 277, 120);
		frame.getContentPane().add(lblBloodConnect);
	}

}
