import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.event.ActionEvent;

public class HospitalHomePage {

	public JFrame frame;
	public JTextField textField;

	/**
	 * Launch the application.
	 */
	
		
	
	/**
	 * Create the application.
	 */
	public HospitalHomePage(String uname) {
		initialize(uname);
	}
	public void close(JFrame Window){
		Window.setVisible(false);
	}
	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize(String uname) {
		frame = new JFrame();
		frame.setBounds(100, 100, 550, 399);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Blood Connect ++");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(272, 21, 252, 97);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField.setBounds(26, 53, 112, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.setText(uname);
		
		JLabel lblNewLabel_1 = new JLabel("Blood Group");
		lblNewLabel_1.setBounds(26, 164, 81, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select", "A+", "B+", "A-", "B-", "AB+", "O+", "AB-", "O-"}));
		comboBox.setBounds(117, 164, 105, 20);
		frame.getContentPane().add(comboBox);
		
		JButton btnNewButton = new JButton("Find User");
		btnNewButton.setBounds(261, 164, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBloodAvailability = new JButton("Blood Availability");
		btnBloodAvailability.setBounds(26, 253, 140, 23);
		frame.getContentPane().add(btnBloodAvailability);
		
		JButton btnSignOut = new JButton("Sign Out");
		btnSignOut.setBounds(377, 310, 128, 23);
		frame.getContentPane().add(btnSignOut);
		
		JButton btnContactBloodBak = new JButton("Contact Blood Bank");
		btnContactBloodBak.setBounds(206, 253, 160, 23);
		frame.getContentPane().add(btnContactBloodBak);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.setBounds(206, 310, 140, 23);
		frame.getContentPane().add(btnChangePassword);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "jdbc:mysql://localhost:3306/bloodconnect";
				 	String username = "root";
				   String password = "";
				  
				   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
				   Statement st=conn.createStatement();
				   String q="Select pincode from contact where id='"+uname+"'";
				   ResultSet rs=st.executeQuery(q);
				   rs.next();
				   String pin = rs.getString("pincode");
				   java.sql.Connection conn1 = DriverManager.getConnection(url,username,password);
				   Statement st1=conn1.createStatement();
				   
				   String qq="Select username,phone,lastdonated from donor where pincode='"+pin+"' and bloodgroup='"+comboBox.getSelectedItem()+"' ORDER BY username DESC LIMIT 10";
				   ResultSet rs1=st1.executeQuery(qq);
				   System.out.println("Donors Near You with Blood Group = "+comboBox.getSelectedItem());
				   while (rs1.next()) {
			            System.out.println(rs1.getString(1)+" "+rs1.getString(2));
			        }
				   conn.close();
				}catch(Exception a) {
					System.out.println(a);
				}
			}
		});
		
		btnBloodAvailability.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "jdbc:mysql://localhost:3306/bloodconnect";
				 	String username = "root";
				   String password = "";
				  
				   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
				   Statement st=conn.createStatement();
				   String q="Select * from bloodavailability where id='"+uname+"'";
				   ResultSet rs=st.executeQuery(q);
				   while (rs.next()){
					   System.out.println("A+ "+rs.getString(3));
					   System.out.println("A- "+rs.getString(4));
					   System.out.println("B+ "+rs.getString(5));
					   System.out.println("B- "+rs.getString(6));
					   System.out.println("AB+ "+rs.getString(7));
					   System.out.println("AB- "+rs.getString(8));
					   System.out.println("O+ "+rs.getString(9));
					   System.out.println("O- "+rs.getString(10));
				   }
				   conn.close();
				}catch(Exception a) {
					System.out.println(a);
				}
			}
		});
		
		btnContactBloodBak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "jdbc:mysql://localhost:3306/bloodconnect";
				 	String username = "root";
				   String password = "";
				  
				   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
				   Statement st=conn.createStatement();
				   String q="Select pincode from contact where id='"+uname+"'";
				   ResultSet rs=st.executeQuery(q);
				   rs.next();
				   String pin = rs.getString("pincode");
				   java.sql.Connection conn1 = DriverManager.getConnection(url,username,password);
				   Statement st1=conn1.createStatement();
				   
				   String qq="Select id,phone from contact where utype='BloodBank' and pincode='"+pin+"' ORDER BY id DESC LIMIT 10";
				   ResultSet rs1=st1.executeQuery(qq);
				   System.out.println("BloodBanks Near You");
				   while (rs1.next()) {
			            System.out.println(rs1.getString(1)+" "+rs1.getString(2));
			        }
				   conn.close();
				}catch(Exception a) {
					System.out.println(a);
				}
			}
		});
		
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				close(frame);
				String s="Log Out successfully";
				JOptionPane.showConfirmDialog(null, s);
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							SignupPage window = new SignupPage();
							window.frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdatePassword window = new UpdatePassword(textField.getText(),"Hospital");
				window.frame.setVisible(true);
			}
		});
		
	}

}
