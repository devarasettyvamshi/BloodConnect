import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.event.ActionEvent;

public class UpdateInfo {

	public JFrame frame;
	public UpdateInfo(String uname) {
		initialize(uname);
	}
	public static void close(JFrame Window){
		Window.setVisible(false);
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String uname) {
		frame = new JFrame();
		frame.setBounds(100, 100, 652, 502);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblUpdatePassword = new JLabel("UPDATE INFO");
		lblUpdatePassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUpdatePassword.setBounds(200, 23, 1390, 27);
		frame.getContentPane().add(lblUpdatePassword);
		
		JComboBox var1 = new JComboBox();
		var1.setModel(new DefaultComboBoxModel(new String[] {"Select", "Email", "Phone", "Pincode"}));
		var1.setBounds(185, 81, 127, 20);
		frame.getContentPane().add(var1);
		
		JTextField var = new JTextField();
		var.setColumns(10);
		var.setBounds(185, 121, 127, 20);
		frame.getContentPane().add(var);
		
		JButton Update = new JButton("Update");
		Update.setBounds(185, 161, 127, 20);
		frame.getContentPane().add(Update);
		
		Update.addActionListener(new ActionListener() {
			 
			public void actionPerformed(ActionEvent e) {
				
				if(var.getText()!=null & var1.getSelectedItem()!="Select" ) {
					//JOptionPane.showConfirmDialog(null, "inside");
					String q="Update donor SET "+var1.getSelectedItem()+"='"+var.getText()+"' WHERE username='"+uname+"'";
				

					try {
						String url = "jdbc:mysql://localhost:3306/bloodconnect";
					 	String username = "root";
					   String password = "";
					  
					   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
					   Statement st=conn.createStatement();
						int rs=st.executeUpdate(q);
							String s="Updated Successfully";
							JOptionPane.showConfirmDialog(null, s);
							EventQueue.invokeLater(new Runnable() {
								public void run() {
									try {
								//		UserHomePage window = new UserHomePage();
									//	window.frame.setVisible(true);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							});
						
						close(frame);
						
						
						conn.close();
					}catch(Exception s) {
						System.out.println(s);
					}
				
					
				}
				else{
					if(var1.getSelectedItem()=="Select"){
						JOptionPane.showConfirmDialog(null, "Please Select proper Attribute");
					}
					else{
						JOptionPane.showConfirmDialog(null, "Your Update Field is empty");
					}
				}
			
			
			}
		});
		
		JLabel lblConfirmPassword11 = new JLabel("");
		lblConfirmPassword11.setBounds(56, 164, 83, 14);
		frame.getContentPane().add(lblConfirmPassword11);

		
}

}
