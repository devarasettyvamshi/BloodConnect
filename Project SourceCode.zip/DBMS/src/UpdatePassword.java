import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.event.ActionEvent;

public class UpdatePassword {

	public JFrame frame;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public UpdatePassword(String uname,String utype) {
		initialize(uname,utype);
	}
	public static void close(JFrame Window){
		Window.setVisible(false);
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String uname,String utype) {
		frame = new JFrame();
		frame.setBounds(100, 100, 652, 502);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblUpdatePassword = new JLabel("UPDATE PASSWORD");
		lblUpdatePassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUpdatePassword.setBounds(200, 23, 1390, 27);
		frame.getContentPane().add(lblUpdatePassword);
		
		JTextField textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField.setBounds(26, 53, 112, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.setText(uname);

		
		JLabel label = new JLabel("Current Password");
		label.setBounds(56, 84, 150, 14);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("New Password");
		label_1.setBounds(56, 124, 150, 14);
		frame.getContentPane().add(label_1);
		
		JLabel lblConfirmPassword = new JLabel("Confirm Password");
		lblConfirmPassword.setBounds(56, 164, 150, 14);
		frame.getContentPane().add(lblConfirmPassword);
		
		JTextField NewPwd = new JTextField();
		NewPwd.setBounds(185, 124, 127, 20);
		frame.getContentPane().add(NewPwd);
		NewPwd.setColumns(10);
		
		JTextField CurPwd = new JTextField();
		CurPwd.setBounds(185, 84, 127, 20);
		frame.getContentPane().add(CurPwd);
		CurPwd.setColumns(10);
		
		JTextField ConPwd = new JTextField();
		ConPwd.setBounds(185, 164, 127, 20);
		frame.getContentPane().add(ConPwd);
		ConPwd.setColumns(10);
		
		JButton change = new JButton("Change");
		change.setBounds(185, 229, 89, 23);
		frame.getContentPane().add(change);
		
		change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(utype=="BloodBank"){	
				if(NewPwd.getText()!=null & CurPwd.getText()!=null & ConPwd.getText()!=null & NewPwd.getText().equals(ConPwd.getText())) {
					//JOptionPane.showConfirmDialog(null, "inside");
					String q="UPDATE BloodBank SET password = '"+NewPwd.getText()+"' WHERE bid = '"+uname+"' and password ='"+CurPwd.getText()+"';";
					try {
						String url = "jdbc:mysql://localhost:3306/bloodconnect";
					 	String username = "root";
					   String password = "";
					  
					   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
					   Statement st=conn.createStatement();
						int rs=st.executeUpdate(q);
							String s="Password Updated";
							JOptionPane.showConfirmDialog(null, s);
							EventQueue.invokeLater(new Runnable() {
								public void run() {
									try {
									//	BloodBankHomePage window = new BloodBankHomePage(uname);
									//	window.frame.setVisible(true);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							});
						
						close(frame);
						
						
						conn.close();
					}catch(Exception w) {
						System.out.println(w);
					}
				}else {
					//JOptionPane.showConfirmDialog(null, "else inside");
					if(!(NewPwd.getText().equals(ConPwd.getText()))){
						JOptionPane.showConfirmDialog(null, "Password Did not match");
					}else {
						JOptionPane.showConfirmDialog(null, "Fill all details");
					}
				}
			}
				
				
				else if(utype=="Hospital"){	
				if(NewPwd.getText()!=null & CurPwd.getText()!=null & ConPwd.getText()!=null & NewPwd.getText().equals(ConPwd.getText())) {
					//JOptionPane.showConfirmDialog(null, "inside");
					String q="UPDATE Hospital SET password = '"+NewPwd.getText()+"' WHERE hid = '"+uname+"' and password ='"+CurPwd.getText()+"';";
					try {
						String url = "jdbc:mysql://localhost:3306/bloodconnect";
					 	String username = "root";
					   String password = "";
					  
					   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
					   Statement st=conn.createStatement();
						int rs=st.executeUpdate(q);
							String s="Password Updated";
							JOptionPane.showConfirmDialog(null, s);
							EventQueue.invokeLater(new Runnable() {
								public void run() {
									try {
										//HospitalHomePage window = new HospitalHomePage(uname);
										//window.frame.setVisible(true);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							});
						
						close(frame);
						
						
						conn.close();
					}catch(Exception w) {
						System.out.println(w);
					}
				}else {
					//JOptionPane.showConfirmDialog(null, "else inside");
					if(!(NewPwd.getText().equals(ConPwd.getText()))) {
						JOptionPane.showConfirmDialog(null, "Password Did not match");
					}else {
						JOptionPane.showConfirmDialog(null, "Fill all details");
					}
				}
			}
				
				else if(utype=="Donor"){	
					if(NewPwd.getText()!=null & CurPwd.getText()!=null & ConPwd.getText()!=null & NewPwd.getText().equals(ConPwd.getText())) {
						//JOptionPane.showConfirmDialog(null, "inside");
						String q="UPDATE Donor SET password = '"+NewPwd.getText()+"' WHERE username = '"+uname+"' and password ='"+CurPwd.getText()+"';";
						String qq = "Select * from donor where username='"+uname+"'";
						try {
							String url = "jdbc:mysql://localhost:3306/bloodconnect";
						 	String username = "root";
						   String password = "";
						  
						   java.sql.Connection conn = DriverManager.getConnection(url,username,password);
						   Statement st=conn.createStatement();
							int rs=st.executeUpdate(q);
							java.sql.Connection conn1 = DriverManager.getConnection(url,username,password);
							   Statement st1=conn.createStatement();
								ResultSet rs1=st1.executeQuery(qq);
								rs1.next();
									String ld = rs1.getString(8);
								String s="Password Updated";
								JOptionPane.showConfirmDialog(null, s);
								EventQueue.invokeLater(new Runnable() {
									public void run() {
										try {
										//	UserHomePage window = new UserHomePage(uname,ld);
										//	window.frame.setVisible(true);
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
								});
							
							close(frame);
							
							
							conn.close();
						}catch(Exception w) {
							System.out.println(w);
						}
					}else {
						//JOptionPane.showConfirmDialog(null, "else inside");
						if(!(NewPwd.getText().equals(ConPwd.getText()))) {
							JOptionPane.showConfirmDialog(null, "Password Did not match");
						}else {
							JOptionPane.showConfirmDialog(null, "Fill all details");
						}
					}
				}
			
			
			
				
			}
		});
		
		JLabel lblConfirmPassword11 = new JLabel("");
		lblConfirmPassword11.setBounds(56, 164, 83, 14);
		frame.getContentPane().add(lblConfirmPassword11);
		
	}

}
